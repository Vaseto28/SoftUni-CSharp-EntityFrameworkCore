﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer;

public class StartUp
{
    public static void Main()
    {
        CarDealerContext ctx = new CarDealerContext();
        string inputJson = File.ReadAllText("../../../Datasets/sales.json");

        Console.WriteLine(ImportSales(ctx, inputJson));
    }

    public static string ImportSuppliers(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportSuppliersDTO[]>(inputJson);

        List<Supplier> suppliers = new List<Supplier>();
        foreach (var dto in dtos)
        {
            Supplier supplier = new Supplier()
            {
                Name = dto.Name,
                IsImporter = dto.IsImporter
            };

            suppliers.Add(supplier);
        }

        context.AddRange(suppliers);
        context.SaveChangesAsync();

        return $"Successfully imported {suppliers.Count}.";
    }

    public static string ImportParts(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportPartsDTO[]>(inputJson);

        List<Part> parts = new List<Part>();
        foreach (var dto in dtos)
        {
            if (context.Suppliers.Find(dto.SupplierId) == null)
            {
                continue;
            }

            Part part = new Part()
            {
                Name = dto.Name,
                Price = dto.Price,
                Quantity = dto.Quantity,
                SupplierId = dto.SupplierId
            };

            parts.Add(part);
        }

        context.AddRange(parts);
        context.SaveChangesAsync();

        return $"Successfully imported {parts.Count}.";
    }

    public static string ImportCars(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportCarDTO[]>(inputJson);

        List<Car> cars = new List<Car>();
        foreach (var dto in dtos)
        {
            Car car = new Car()
            {
                Make = dto.Make,
                Model = dto.Model,
                TravelledDistance = dto.TravelledDistance,
                PartsCars = dto.PartsCars
            };

            cars.Add(car);
        }

        context.AddRange(cars);
        context.SaveChangesAsync();

        return $"Successfully imported {cars.Count}."; 
    }

    public static string ImportCustomers(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportCustomersDTO[]>(inputJson);

        List<Customer> customers = new List<Customer>();
        foreach (var dto in dtos)
        {
            Customer customer = new Customer()
            {
                Name = dto.Name,
                BirthDate = dto.BirthDate,
                IsYoungDriver = dto.IsYoungDriver
            };

            customers.Add(customer);
        }

        context.AddRange(customers);
        context.SaveChangesAsync();

        return $"Successfully imported {customers.Count}.";
    }

    public static string ImportSales(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportSalesDTO[]>(inputJson);

        List<Sale> sales = new List<Sale>();
        foreach (var dto in dtos)
        {
            Sale sale = new Sale()
            {
                CarId = dto.CarId,
                CustomerId = dto.CustomerId,
                Discount = dto.Discount
            };

            sales.Add(sale);
        }

        context.AddRange(sales);
        context.SaveChangesAsync();

        return $"Successfully imported {sales.Count}.";
    }
}