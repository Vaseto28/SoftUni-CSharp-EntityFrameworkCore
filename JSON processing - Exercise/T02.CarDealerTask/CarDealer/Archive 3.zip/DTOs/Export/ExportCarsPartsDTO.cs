﻿using Newtonsoft.Json;

namespace CarDealer.DTOs.Export;

public class ExportCarsPartsDTO
{
	[JsonProperty("car")]
	public ExportCarsDTO Car { get; set; } = null!;

	[JsonProperty("parts")]
	public ExportPartsDTO[] Parts { get; set; } = null!;
}

