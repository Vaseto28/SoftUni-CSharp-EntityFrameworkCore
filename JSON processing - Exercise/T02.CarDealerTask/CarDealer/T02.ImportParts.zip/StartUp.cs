﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer;

public class StartUp
{
    public static void Main()
    {
        CarDealerContext ctx = new CarDealerContext();
        string inputJson = File.ReadAllText("../../../Datasets/parts.json");

        Console.WriteLine(ImportParts(ctx, inputJson));
    }

    public static string ImportSuppliers(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportSuppliersDTO[]>(inputJson);

        List<Supplier> suppliers = new List<Supplier>();
        foreach (var dto in dtos)
        {
            Supplier supplier = new Supplier()
            {
                Name = dto.Name,
                IsImporter = dto.IsImporter
            };

            suppliers.Add(supplier);
        }

        context.AddRange(suppliers);
        context.SaveChangesAsync();

        return $"Successfully imported {suppliers.Count}.";
    }

    public static string ImportParts(CarDealerContext context, string inputJson)
    {
        var dtos = JsonConvert.DeserializeObject<ImportPartsDTO[]>(inputJson);

        List<Part> parts = new List<Part>();
        foreach (var dto in dtos)
        {
            if (context.Suppliers.Find(dto.SupplierId) == null)
            {
                continue;
            }

            Part part = new Part()
            {
                Name = dto.Name,
                Price = dto.Price,
                Quantity = dto.Quantity,
                SupplierId = dto.SupplierId
            };

            parts.Add(part);
        }

        context.AddRange(parts);
        context.SaveChangesAsync();

        return $"Successfully imported {parts.Count}.";
    }
}