﻿namespace CarDealer.Data;

public static class Configuration
{
    public const string ConnectionString = @"Server=.,1433;Initial Catalog=CarDealer;User ID=sa;Password=28120601V;Encrypt=False;TrustServerCertificate=True;";
}
