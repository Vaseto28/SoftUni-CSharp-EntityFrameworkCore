﻿using Newtonsoft.Json;

namespace CarDealer.DTOs.Export;

public class ExportCarsDTO
{
	public ExportCarsDTO()
	{
		this.Parts = new List<ExportPartsDTO>();
	}

	[JsonProperty("Make")]
	public string Make { get; set; } = null!;

	[JsonProperty("Model")]
	public string Model { get; set; } = null!;

	[JsonProperty("TraveledDistance")]
	public long TraveledDistance { get; set; }

	public ICollection<ExportPartsDTO> Parts { get; set; }
}

