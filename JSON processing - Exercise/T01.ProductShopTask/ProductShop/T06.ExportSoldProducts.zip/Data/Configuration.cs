﻿namespace ProductShop.Data;

public static class Configuration
{
    public const string ConnectionString =
        @"Server=.,1433;Initial Catalog=ProductsShop;User ID=sa;Password=28120601V;TrustServerCertificate=True;";
}