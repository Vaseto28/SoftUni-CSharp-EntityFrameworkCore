﻿namespace ProductShop.Data;

public static class Configuration
{
    public const string ConnectionString =
        @"Server=.,1433;Initial Catalog=ProductShop;Persist Security Info=False;User ID=sa;Password=28120601V;TrustServerCertificate=True;";
}