﻿namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            Console.WriteLine(ExportAlbumsInfo(context, 9));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var albums = context.Albums
                .Where(a => a.ProducerId == producerId)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var a in albums.OrderByDescending(x => x.Price))
            {
                sb.AppendLine($"-AlbumName: {a.Name}");
                sb.AppendLine($"-ReleaseDate: {a.ReleaseDate.ToString("MM/dd/yyyy")}");
                sb.AppendLine($"-ProducerName: {a.Producer.Name}");

                if (a.Songs.Count != 0)
                {
                    sb.AppendLine("-Songs:");
                    int songNumber = 1;
                    foreach (var s in a.Songs.OrderByDescending(x => x.Name).ThenBy(x => x.Writer.Name))
                    {
                        sb.AppendLine($"---#{songNumber}");
                        sb.AppendLine($"---SongName: {s.Name}");
                        sb.AppendLine($"---Price: {s.Price:f2}");
                        sb.AppendLine($"---Writer: {s.Writer.Name}");

                        songNumber++;
                    }
                }

                sb.AppendLine($"-AlbumPrice: {a.Price:f2}");
            }

            return sb.ToString().Trim();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
