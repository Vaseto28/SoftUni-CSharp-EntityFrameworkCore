﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.;Database=MusicHub;Trusted_Connection=True;User ID=sa;Password=28120601V;integrated security=False;";
    }
}
