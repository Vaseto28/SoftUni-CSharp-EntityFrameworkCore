﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.,1433;Initial Catalog=BookShop;User ID=sa;Password=28120601V;TrustServerCertificate=True;";
    }
}
