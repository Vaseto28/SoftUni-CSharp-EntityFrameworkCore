﻿namespace BookShop
{
    using System.Text;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            Console.WriteLine(GetGoldenBooks(db));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            bool hasParsed = Enum.TryParse(typeof(AgeRestriction), command, true, out object AgeRestrictionObj);
            AgeRestriction ageRestriction;
            if (hasParsed)
            {
                ageRestriction = (AgeRestriction)AgeRestrictionObj;

                var bookTitles = context.Books
                .Where(x => x.AgeRestriction == ageRestriction)
                .OrderBy(x => x.Title)
                .Select(x => x.Title)
                .ToArray();

                return string.Join(Environment.NewLine, bookTitles);
            }

            return null;
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            string[] bookTitles = context.Books
                .Where(x => x.EditionType == (EditionType)2 && x.Copies < 5000)
                .OrderBy(x => x.BookId)
                .Select(x => x.Title)
                .ToArray();

            return String.Join(Environment.NewLine, bookTitles);
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            throw new NotImplementedException();

        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {

            throw new NotImplementedException();
        }

        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            throw new NotImplementedException();

        }

        public static string CountCopiesByAuthor(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetMostRecentBooks(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static void IncreasePrices(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static int RemoveBooks(BookShopContext context)
        {
            throw new NotImplementedException();

        }
    }
}


