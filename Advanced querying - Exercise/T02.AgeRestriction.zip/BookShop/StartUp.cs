﻿namespace BookShop
{
    using System.Text;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            string givenAgeRestriction = Console.ReadLine();

            Console.WriteLine(GetBooksByAgeRestriction(db, givenAgeRestriction));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            bool hasParsed = Enum.TryParse(typeof(AgeRestriction), command, true, out object AgeRestrictionObj);
            AgeRestriction ageRestriction;
            if (hasParsed)
            {
                ageRestriction = (AgeRestriction)AgeRestrictionObj;

                var bookTitles = context.Books
                .Where(x => x.AgeRestriction == ageRestriction)
                .OrderBy(x => x.Title)
                .Select(x => x.Title)
                .ToArray();

                StringBuilder sb = new StringBuilder();
                foreach (var bookTitle in bookTitles)
                {
                    sb.AppendLine(bookTitle);
                }

                return sb.ToString().Trim();
            }

            return null;
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            throw new NotImplementedException();

        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {

            throw new NotImplementedException();
        }

        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            throw new NotImplementedException();

        }

        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            throw new NotImplementedException();

        }

        public static string CountCopiesByAuthor(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static string GetMostRecentBooks(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static void IncreasePrices(BookShopContext context)
        {
            throw new NotImplementedException();

        }

        public static int RemoveBooks(BookShopContext context)
        {
            throw new NotImplementedException();

        }
    }
}


