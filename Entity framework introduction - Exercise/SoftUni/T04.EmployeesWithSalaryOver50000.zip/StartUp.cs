﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System.Text;

namespace SoftUni;

public class StartUp
{
    public static void Main(string[] args)
    {
        SoftUniContext dbCtx = new SoftUniContext();

        Console.WriteLine(GetEmployeesWithSalaryOver50000(dbCtx));
    }

    //Task 3
    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        var employees = context.Employees
            .OrderBy(e => e.EmployeeId)
            .Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.MiddleName,
                e.JobTitle,
                e.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }

    //Task 4
    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        var employees = context.Employees
            .AsNoTracking()
            .Where(x => x.Salary > 50000)
            .OrderBy(x => x.FirstName)
            .Select(x => new
            {
                x.FirstName,
                x.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }
}