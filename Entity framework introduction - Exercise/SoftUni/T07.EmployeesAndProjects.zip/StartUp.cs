﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni;

public class StartUp
{
    public static void Main(string[] args)
    {
        SoftUniContext dbCtx = new SoftUniContext();

        Console.WriteLine(GetEmployeesInPeriod(dbCtx));
    }

    //Task 3
    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        var employees = context.Employees
            .OrderBy(e => e.EmployeeId)
            .Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.MiddleName,
                e.JobTitle,
                e.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }

    //Task 4
    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        var employees = context.Employees
            .AsNoTracking()
            .Where(x => x.Salary > 50000)
            .OrderBy(x => x.FirstName)
            .Select(x => new
            {
                x.FirstName,
                x.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }

    //Task 5
    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        var employees = context.Employees
            .AsNoTracking()
            .OrderBy(x => x.Salary)
            .ThenByDescending(x => x.FirstName)
            .Where(x => x.Department.Name == "Research and Development")
            .Select(x => new
            {
                x.FirstName,
                x.LastName,
                x.Salary
            })
            .ToArray();

        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} from Research and Development - ${e.Salary:f2}");
        }

        return sb.ToString().Trim();
    }

    //Task 6
    public static string AddNewAddressToEmployee(SoftUniContext context)
    {
        Address address = new Address()
        {
            AddressText = "Vitoshka 15",
            TownId = 4
        };

        context.Addresses.Add(address);
        context.SaveChanges();

        var employee = context.Employees
            .Where(x => x.LastName == "Nakov")
            .ToArray()[0];

        employee.AddressId = address.AddressId;
        employee.Address = address;

        context.SaveChanges();

        var adressTexts = context.Employees
            .AsNoTracking()
            .OrderByDescending(x => x.AddressId)
            .Take(10)
            .Select(x => x.Address!.AddressText)
            .ToArray();

        StringBuilder sb = new StringBuilder();
        foreach (var a in adressTexts)
        {
            sb.AppendLine(a);
        }

        return sb.ToString().Trim();
    }

    //Task 7
    public static string GetEmployeesInPeriod(SoftUniContext context)
    {
        var employees = context.Employees
            .Take(10)
            .Select(x => new
            {
                x.FirstName,
                x.LastName,
                ManagerFirstName = x.Manager!.FirstName,
                ManagerLastName = x.Manager!.LastName,
                Projects = x.EmployeesProjects
                    .Select(x => new
                    {
                        ProjectName = x.Project.Name,
                        StartDate = x.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt"),
                        EndDate = x.Project.EndDate.HasValue ?
                            x.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt") : "not finished"
                    })
            })
            .ToArray();

        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} - Manager: {e.ManagerFirstName} {e.ManagerLastName}");

            foreach (var p in e.Projects)
            {
                DateTime startDateComparer = new DateTime(2001, 1, 1);
                DateTime endDateComparer = new DateTime(2003, 12, 12);

                if (DateTime.Parse(p.StartDate) >= startDateComparer && DateTime.Parse(p.StartDate) <= endDateComparer)
                {
                    sb.AppendLine($"--{p.ProjectName} - {p.StartDate} - {p.EndDate}");
                }
            }
        }

        return sb.ToString().Trim();
    }
}