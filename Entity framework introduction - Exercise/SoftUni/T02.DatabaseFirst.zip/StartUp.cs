﻿using SoftUni.Data;

namespace SoftUni;

class Startup
{
    public static void Main(string[] args)
    {
        SoftUniContext dbCtx = new SoftUniContext();
        Console.WriteLine("Seccessful!");
    }
}