﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System.Text;

namespace SoftUni;

public class StartUp
{
    public static void Main(string[] args)
    {
        SoftUniContext dbCtx = new SoftUniContext();

        Console.WriteLine(GetEmployeesFromResearchAndDevelopment(dbCtx));
    }

    //Task 3
    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        var employees = context.Employees
            .OrderBy(e => e.EmployeeId)
            .Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.MiddleName,
                e.JobTitle,
                e.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }

    //Task 4
    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        var employees = context.Employees
            .AsNoTracking()
            .Where(x => x.Salary > 50000)
            .OrderBy(x => x.FirstName)
            .Select(x => new
            {
                x.FirstName,
                x.Salary
            })
            .ToArray();

        StringBuilder result = new StringBuilder();

        foreach (var e in employees)
        {
            result.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }

        return result.ToString().Trim();
    }

    //Task 5
    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        var employees = context.Employees
            .AsNoTracking()
            .OrderBy(x => x.Salary)
            .ThenByDescending(x => x.FirstName)
            .Where(x => x.Department.Name == "Research and Development")
            .Select(x => new
            {
                x.FirstName,
                x.LastName,
                x.Salary
            })
            .ToArray();

        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} from Research and Development - ${e.Salary:f2}");
        }

        return sb.ToString().Trim();
    }
}