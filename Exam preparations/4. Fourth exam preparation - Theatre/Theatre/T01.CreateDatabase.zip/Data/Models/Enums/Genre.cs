﻿namespace Theatre.Data.Models.Enums;

public enum Genre
{
    Drama,
    Comedy,
    Romance,
    Musical
}

