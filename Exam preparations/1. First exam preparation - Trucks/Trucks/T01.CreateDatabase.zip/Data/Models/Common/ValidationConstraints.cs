﻿namespace Trucks.Data.Models.Common;

public static class ValidationConstraints
{
    //Client
    public const int ClientNameMaxLength = 40;
    public const int ClientNationalityMaxLength = 40;

    //Dispatcher
    public const int DespatcherNameMaxLength = 40;
}

