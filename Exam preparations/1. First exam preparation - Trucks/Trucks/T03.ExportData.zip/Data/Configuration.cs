﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Trucks;User ID=sa;Password=28120601V;Trusted_Connection=True;TrustServerCertificate=True;Integrated security=false";
    }
}