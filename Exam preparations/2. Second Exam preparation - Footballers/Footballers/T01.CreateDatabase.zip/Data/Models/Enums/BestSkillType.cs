﻿namespace Footballers.Data.Models.Enums;

public enum BestSkillType
{
    Defence,
    Dribble,
    Pass,
    Shoot,
    Speed
}

