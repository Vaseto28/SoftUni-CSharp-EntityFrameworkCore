﻿namespace TeisterMask.Data.Models.Enums;

public enum LabelType
{
    Priority,
    CSharpAdvanced,
    JavaAdvanced,
    EntityFramework,
    Hibernate
}

