﻿namespace TeisterMask.DataProcessor
{
    using Data;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            throw new NotImplementedException();
        }
    }
}