﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=TeisterMaskExam;User ID=sa;Password=28120601V;TrustServerCertificate=True;Integrated Security=False;Encrypt=False";
    }
}
