﻿using System.Xml.Serialization;
using AutoMapper.Configuration.Annotations;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using ProductShop.Utilities;

namespace ProductShop;

public class StartUp
{
    public static void Main()
    {
        ProductShopContext context = new ProductShopContext();
        string inputXml = File.ReadAllText("../../../Datasets/products.xml");

        Console.WriteLine(ImportProducts(context, inputXml));
    }

    public static string ImportUsers(ProductShopContext context, string inputXml)
    {
        XmlHelper helper = new XmlHelper();
        var dtos = helper.Deserialize<ImportUsersDTO[]>("Users", inputXml);

        List<User> users = new List<User>();
        foreach (var dto in dtos)
        {
            if (String.IsNullOrEmpty(dto.FirstName) || string.IsNullOrEmpty(dto.LastName))
            {
                continue;
            }

            User user = new User()
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Age = dto.Age
            };

            users.Add(user);
        }

        context.AddRange(users);
        context.SaveChanges();

        return $"Successfully imported {users.Count}";
    }

    public static string ImportProducts(ProductShopContext context, string inputXml)
    {
        XmlHelper helper = new XmlHelper();

        var dtos = helper.Deserialize<ImportProductsDTO[]>("Products", inputXml);

        List<Product> products = new List<Product>();
        foreach (var dto in dtos)
        {
            if (string.IsNullOrEmpty(dto.Name))
            {
                continue;
            }

            Product product = new Product()
            {
                Name = dto.Name,
                Price = dto.Price,
                SellerId = dto.SellerId,
                BuyerId = dto.BuyerId
            };

            products.Add(product);
        }

        context.Products.AddRange(products);
        context.SaveChanges();

        return $"Successfully imported {products.Count}";
    }
}