﻿using System.Xml.Serialization;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using ProductShop.Utilities;

namespace ProductShop;

public class StartUp
{
    public static void Main()
    {
        ProductShopContext context = new ProductShopContext();
        string inputXml = File.ReadAllText("../../../Datasets/users.xml");

        Console.WriteLine(ImportUsers(context, inputXml));
    }

    public static string ImportUsers(ProductShopContext context, string inputXml)
    {
        XmlHelper helper = new XmlHelper();
        var dtos = helper.Deserialize<ImportUsersDTO[]>("Users", inputXml);

        List<User> users = new List<User>();
        foreach (var dto in dtos)
        {
            if (String.IsNullOrEmpty(dto.FirstName) || string.IsNullOrEmpty(dto.LastName))
            {
                continue;
            }

            User user = new User()
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Age = dto.Age
            };

            users.Add(user);
        }

        context.AddRange(users);
        context.SaveChanges();

        return $"Successfully imported {users.Count}";
    }
}