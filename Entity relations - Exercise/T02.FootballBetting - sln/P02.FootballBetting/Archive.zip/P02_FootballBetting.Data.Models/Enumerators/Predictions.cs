﻿namespace P02_FootballBetting.Data.Models.Enumerators;

public enum Predictions
{
	Draw = 0,
	Win = 1,
	Lose = 2
}

