﻿namespace P02.FootballBetting;

public class StartUp
{
    public static void Main(string[] args)
    {

    }
}